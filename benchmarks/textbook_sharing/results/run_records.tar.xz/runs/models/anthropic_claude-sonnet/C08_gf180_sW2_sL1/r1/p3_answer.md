```python
plans = {0: axis_plan(arrangement="block", orientation="seek_SD", diffusion="all_legal", gate="per_device", strap_start="bottom", contact_end="right"), 1: axis_plan(arrangement="block", orientation="seek_SD", diffusion="all_legal", gate="per_net", strap_start="bottom", contact_end="right")}
```
