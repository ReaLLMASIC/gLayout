```python
plans = {0: SharingPlan(finger_order=[("M1", i) for i in range(16)] + [("M2", i) for i in range(16)] + [("M3", i) for i in range(16)],
            orientations=["SD", "DS"] * 8 + ["SD", "DS"] * 8 + ["DS", "SD"] * 8,
            diffusion_joins=[True] * 47,
            gate_groups=[GateGroup(fingers=tuple(range(0, 16)), side="bottom", pad_end="left"),
                         GateGroup(fingers=tuple(range(16, 32)), side="bottom", pad_end="left"),
                         GateGroup(fingers=tuple(range(32, 48)), side="bottom", pad_end="left")]),
         1: axis_plan(arrangement="block", orientation="alt_SD", diffusion="all_legal", gate="per_net", strap_start="bottom", contact_end="left")}
```
