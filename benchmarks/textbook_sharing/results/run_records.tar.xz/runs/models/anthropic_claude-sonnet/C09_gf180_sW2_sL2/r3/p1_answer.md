```python
plans = {0: SharingPlan(finger_order=[("M3", i) for i in range(16)] + [("M1", i) for i in range(16)] + [("M2", i) for i in range(16)] + [("M4", i) for i in range(16)],
            orientations=["SD", "DS"] * 8 + ["DS", "SD"] * 8 + ["DS", "SD"] * 8 + ["SD", "DS"] * 8,
            diffusion_joins=[True] * 31 + [False] + [True] * 31,
            gate_groups=[GateGroup(fingers=tuple(range(0, 16)), side="bottom", pad_end="left"),
                         GateGroup(fingers=tuple(range(16, 32)), side="bottom", pad_end="left"),
                         GateGroup(fingers=tuple(range(32, 48)), side="bottom", pad_end="left"),
                         GateGroup(fingers=tuple(range(48, 64)), side="bottom", pad_end="left")]),
         1: SharingPlan(finger_order=[("M5", i) for i in range(16)] + [("M7", i) for i in range(16)] + [("M8", i) for i in range(16)] + [("M6", i) for i in range(16)],
            orientations=["SD", "DS"] * 8 + ["DS", "SD"] * 8 + ["DS", "SD"] * 8 + ["SD", "DS"] * 8,
            diffusion_joins=[True] * 31 + [False] + [True] * 31,
            gate_groups=[GateGroup(fingers=tuple(range(0, 16)), side="bottom", pad_end="left"),
                         GateGroup(fingers=tuple(range(16, 32)), side="bottom", pad_end="left"),
                         GateGroup(fingers=tuple(range(32, 48)), side="bottom", pad_end="left"),
                         GateGroup(fingers=tuple(range(48, 64)), side="bottom", pad_end="left")])}
```
