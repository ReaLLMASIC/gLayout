```python
plans = {0: SharingPlan(finger_order=[("M1", 0), ("M1", 1), ("M1", 2), ("M1", 3), ("M1", 4), ("M1", 5), ("M1", 6), ("M1", 7), ("M3", 0), ("M3", 1), ("M3", 2), ("M3", 3), ("M3", 4), ("M3", 5), ("M3", 6), ("M3", 7), ("M2", 0), ("M2", 1), ("M2", 2), ("M2", 3), ("M2", 4), ("M2", 5), ("M2", 6), ("M2", 7), ("M4", 0), ("M4", 1), ("M4", 2), ("M4", 3), ("M4", 4), ("M4", 5), ("M4", 6), ("M4", 7)],
            orientations=["SD", "DS"] * 16,
            diffusion_joins=[True] * 7 + [False] + [True] * 7 + [False] + [True] * 15,
            gate_groups=[GateGroup(fingers=tuple(range(0, 16)), side="bottom", pad_end="left"),
                         GateGroup(fingers=tuple(range(16, 32)), side="bottom", pad_end="left")])}
```
