```python
plans = {0: SharingPlan(finger_order=[("M1", 0), ("M1", 1), ("M1", 2), ("M1", 3), ("M1", 4), ("M1", 5), ("M1", 6), ("M1", 7), ("M1", 8), ("M1", 9), ("M1", 10), ("M1", 11), ("M1", 12), ("M1", 13), ("M1", 14), ("M1", 15), ("M3", 0), ("M3", 1), ("M3", 2), ("M3", 3), ("M3", 4), ("M3", 5), ("M3", 6), ("M3", 7), ("M3", 8), ("M3", 9), ("M3", 10), ("M3", 11), ("M3", 12), ("M3", 13), ("M3", 14), ("M3", 15), ("M2", 0), ("M2", 1), ("M2", 2), ("M2", 3), ("M2", 4), ("M2", 5), ("M2", 6), ("M2", 7), ("M2", 8), ("M2", 9), ("M2", 10), ("M2", 11), ("M2", 12), ("M2", 13), ("M2", 14), ("M2", 15)],
            orientations=["SD", "DS"] * 8 + ["DS", "SD"] * 8 + ["SD", "DS"] * 8,
            diffusion_joins=[True] * 47,
            gate_groups=[GateGroup(fingers=tuple(range(0, 16)), side="bottom", pad_end="left"), GateGroup(fingers=tuple(range(16, 32)), side="bottom", pad_end="left"), GateGroup(fingers=tuple(range(32, 48)), side="bottom", pad_end="left")]),
         1: axis_plan(arrangement="block", orientation="seek_SD", diffusion="all_legal", gate="per_net", strap_start="bottom", contact_end="left")}
```
