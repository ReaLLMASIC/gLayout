```python
plans = {0: SharingPlan(finger_order=[("M1", 0), ("M2", 0), ("M4", 0), ("M3", 0), ("M3", 1), ("M4", 1), ("M2", 1), ("M1", 1),
                                      ("M1", 2), ("M2", 2), ("M4", 2), ("M3", 2), ("M3", 3), ("M4", 3), ("M2", 3), ("M1", 3),
                                      ("M1", 4), ("M2", 4), ("M4", 4), ("M3", 4), ("M3", 5), ("M4", 5), ("M2", 5), ("M1", 5),
                                      ("M1", 6), ("M2", 6), ("M4", 6), ("M3", 6), ("M3", 7), ("M4", 7), ("M2", 7), ("M1", 7)],
            orientations=["DS", "DS", "SD", "SD", "DS", "DS", "SD", "SD"] * 4,
            diffusion_joins=[True] * 31,
            gate_groups=[GateGroup(fingers=(0, 3, 4, 7, 8, 11, 12, 15, 16, 19, 20, 23, 24, 27, 28, 31), side="top", pad_end="left"),
                         GateGroup(fingers=(1, 2, 5, 6, 9, 10, 13, 14, 17, 18, 21, 22, 25, 26, 29, 30), side="bottom", pad_end="right")])}
```
