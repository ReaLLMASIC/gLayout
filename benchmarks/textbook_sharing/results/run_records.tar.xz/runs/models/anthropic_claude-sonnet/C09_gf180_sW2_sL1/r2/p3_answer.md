```python
plans = {0: SharingPlan(finger_order=[("M1", 0), ("M1", 1), ("M1", 2), ("M1", 3), ("M1", 4), ("M1", 5), ("M1", 6), ("M1", 7), ("M1", 8), ("M1", 9), ("M1", 10), ("M1", 11), ("M1", 12), ("M1", 13), ("M1", 14), ("M1", 15), ("M3", 0), ("M3", 1), ("M3", 2), ("M3", 3), ("M3", 4), ("M3", 5), ("M3", 6), ("M3", 7), ("M3", 8), ("M3", 9), ("M3", 10), ("M3", 11), ("M3", 12), ("M3", 13), ("M3", 14), ("M3", 15), ("M4", 0), ("M4", 1), ("M4", 2), ("M4", 3), ("M4", 4), ("M4", 5), ("M4", 6), ("M4", 7), ("M4", 8), ("M4", 9), ("M4", 10), ("M4", 11), ("M4", 12), ("M4", 13), ("M4", 14), ("M4", 15), ("M2", 0), ("M2", 1), ("M2", 2), ("M2", 3), ("M2", 4), ("M2", 5), ("M2", 6), ("M2", 7), ("M2", 8), ("M2", 9), ("M2", 10), ("M2", 11), ("M2", 12), ("M2", 13), ("M2", 14), ("M2", 15)],
            orientations=["DS", "SD"] * 8 + ["SD", "DS"] * 8 + ["SD", "DS"] * 8 + ["DS", "SD"] * 8,
            diffusion_joins=[True] * 31 + [False] + [True] * 31,
            gate_groups=[GateGroup(fingers=tuple(range(0, 16)), side="bottom", pad_end="left"),
                         GateGroup(fingers=tuple(range(16, 48)), side="bottom", pad_end="left"),
                         GateGroup(fingers=tuple(range(48, 64)), side="bottom", pad_end="left")]),
         1: SharingPlan(finger_order=[("M5", 0), ("M5", 1), ("M5", 2), ("M5", 3), ("M5", 4), ("M5", 5), ("M5", 6), ("M5", 7), ("M5", 8), ("M5", 9), ("M5", 10), ("M5", 11), ("M5", 12), ("M5", 13), ("M5", 14), ("M5", 15), ("M7", 0), ("M7", 1), ("M7", 2), ("M7", 3), ("M7", 4), ("M7", 5), ("M7", 6), ("M7", 7), ("M7", 8), ("M7", 9), ("M7", 10), ("M7", 11), ("M7", 12), ("M7", 13), ("M7", 14), ("M7", 15), ("M8", 0), ("M8", 1), ("M8", 2), ("M8", 3), ("M8", 4), ("M8", 5), ("M8", 6), ("M8", 7), ("M8", 8), ("M8", 9), ("M8", 10), ("M8", 11), ("M8", 12), ("M8", 13), ("M8", 14), ("M8", 15), ("M6", 0), ("M6", 1), ("M6", 2), ("M6", 3), ("M6", 4), ("M6", 5), ("M6", 6), ("M6", 7), ("M6", 8), ("M6", 9), ("M6", 10), ("M6", 11), ("M6", 12), ("M6", 13), ("M6", 14), ("M6", 15)],
            orientations=["SD", "DS"] * 8 + ["DS", "SD"] * 8 + ["DS", "SD"] * 8 + ["SD", "DS"] * 8,
            diffusion_joins=[True] * 31 + [False] + [True] * 31,
            gate_groups=[GateGroup(fingers=tuple(range(0, 16)), side="bottom", pad_end="left"),
                         GateGroup(fingers=tuple(range(16, 48)), side="bottom", pad_end="left"),
                         GateGroup(fingers=tuple(range(48, 64)), side="bottom", pad_end="left")])}
```
