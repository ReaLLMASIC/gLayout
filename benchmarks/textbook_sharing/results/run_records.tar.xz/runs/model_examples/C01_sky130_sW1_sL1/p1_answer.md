```python
plans = {0: axis_plan(arrangement="block", orientation="alt_SD", diffusion="none", gate="per_device", strap_start="bottom", contact_end="left")}
```
