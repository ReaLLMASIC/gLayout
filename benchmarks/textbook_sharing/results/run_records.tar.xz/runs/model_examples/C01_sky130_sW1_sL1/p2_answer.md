```python
plans = {0: SharingPlan(finger_order=[("M1", 0), ("M1", 1), ("M1", 2), ("M1", 3), ("M2", 0), ("M2", 1), ("M2", 2), ("M2", 3)],
            orientations=["SD", "DS", "SD", "DS", "SD", "DS", "SD", "DS"],
            diffusion_joins=[True, True, True, True, True, True, True],
            gate_groups=[GateGroup(fingers=(0, 1, 2, 3, 4, 5, 6, 7), side="bottom", pad_end="left")])}
```
