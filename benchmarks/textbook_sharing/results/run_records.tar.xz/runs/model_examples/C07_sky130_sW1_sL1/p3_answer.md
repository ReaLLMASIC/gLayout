```python
plans = {0: SharingPlan(finger_order=[("M1", 0), ("M1", 1)], orientations=["SD", "SD"], diffusion_joins=[True], gate_groups=[GateGroup(fingers=(0, 1), side="bottom", pad_end="left")]), 1: axis_plan(arrangement="block", orientation="alt_SD", diffusion="none", gate="per_device", strap_start="bottom", contact_end="left")}
```
