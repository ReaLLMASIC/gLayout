```python
plans = {0: fet_row(arrangement="block", orientation="alt_SD", contact_end="left", diffusion="all_legal"), 1: fet_row(arrangement="block", orientation="alt_SD", contact_end="left", diffusion="all_legal")}
```
