```python
plans = {0: fet_row(arrangement="interleave", orientation="alt_DS", contact_end="right")}
```
