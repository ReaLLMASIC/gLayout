```python
plans = {0: fet_row(arrangement="block", orientation="alt_SD", contact_end="left")}
```
