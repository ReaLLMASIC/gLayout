# Task C09_gf180_sW2_sL1
Circuit: telescopic OTA (single-ended) (textbook topology C09).
Process: GlobalFoundries GF180MCU (3.3 V devices).
Target netlist (fixed; sizes in um):
```spice
.subckt C09_gf180_sW2_sL1 VDD VSS VIN1 VIN2 VOUT1 VB1 IB1
MM1 net018 VIN1 IB1 VSS nfet_03v3 w=8u l=0.56u nf=16 m=1
MM2 net016 VIN2 IB1 VSS nfet_03v3 w=8u l=0.56u nf=16 m=1
MM3 net04 VB1 net018 VSS nfet_03v3 w=8u l=0.56u nf=16 m=1
MM4 VOUT1 VB1 net016 VSS nfet_03v3 w=8u l=0.56u nf=16 m=1
MM5 net04 net04 net019 VDD pfet_03v3 w=8u l=0.56u nf=16 m=1
MM6 VOUT1 net04 net017 VDD pfet_03v3 w=8u l=0.56u nf=16 m=1
MM7 net019 net019 VDD VDD pfet_03v3 w=8u l=0.56u nf=16 m=1
MM8 net017 net019 VDD VDD pfet_03v3 w=8u l=0.56u nf=16 m=1
.ends C09_gf180_sW2_sL1
```
Fixed sharing groups and rows (2 groups; you must give a plan for every group index):
group 0 (bottom (NMOS) row, body VSS, unit finger width 0.5 um, L 0.56 um):
    M1: nfet D=net018 G=VIN1 S=IB1 B=VSS, nf=16, total W=8 um
    M2: nfet D=net016 G=VIN2 S=IB1 B=VSS, nf=16, total W=8 um
    M3: nfet D=net04 G=VB1 S=net018 B=VSS, nf=16, total W=8 um
    M4: nfet D=VOUT1 G=VB1 S=net016 B=VSS, nf=16, total W=8 um
group 1 (middle (PMOS) row, body VDD, unit finger width 0.5 um, L 0.56 um):
    M5: pfet D=net04 G=net04 S=net019 B=VDD, nf=16, total W=8 um
    M6: pfet D=VOUT1 G=net04 S=net017 B=VDD, nf=16, total W=8 um
    M7: pfet D=net019 G=net019 S=VDD B=VDD, nf=16, total W=8 um
    M8: pfet D=net017 G=net019 S=VDD B=VDD, nf=16, total W=8 um
Goal: propose plans so that the generated layout passes every check with the smallest full bounding-box area.
