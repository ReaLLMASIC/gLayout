Each example shows a development circuit (NOT your task circuit), programs that were submitted for it, and the tool report each program received.  Areas of development circuits say nothing about your task's areas.

## Example: C01 (sky130, development size)
Case C01_sky130_sW1_sL1
Circuit: basic current mirror (textbook topology C01).
Process: SkyWater SKY130 (1.8 V devices).
Target netlist (fixed; sizes in um):
```spice
.subckt C01_sky130_sW1_sL1 VSS IB1 IOUT1
XM1 IB1 IB1 VSS VSS sky130_fd_pr__nfet_01v8 w=2 l=0.6 nf=4
XM2 IOUT1 IB1 VSS VSS sky130_fd_pr__nfet_01v8 w=2 l=0.6 nf=4
.ends C01_sky130_sW1_sL1
```
Fixed sharing groups and rows (1 groups; you must give a plan for every group index):
group 0 (bottom (NMOS) row, body VSS, unit finger width 0.5 um, L 0.6 um):
    M1: nfet D=IB1 G=IB1 S=VSS B=VSS, nf=4, total W=2 um
    M2: nfet D=IOUT1 G=IB1 S=VSS B=VSS, nf=4, total W=2 um
Goal: propose plans so that the generated layout passes every check with the smallest full bounding-box area.


### Program 1
```python
plans = {0: fet_row(arrangement="block", orientation="alt_SD", contact_end="left")}
```
### Tool report for program 1
```
Proposal 1: built and verified. Overall status: auto_passed.
  stages: drc=passed, lvs=passed, constraints=passed, pex=passed, physical=passed, post-layout simulation/spec=passed
  full-DUT bounding box: 11.005 x 7.095 um = 78.0805 um^2
    row n: width 8.23 um (+ taps 1.70), height 3.565 um; cells grp0 8.23x2.785
    routing channels: heights [1.88, 3.1] um; channel strategy shared
  group 0: active islands 2, cross-device shared diffusion nodes 0, cross-device shared gate conductors 0
```

### Program 2
```python
plans = {0: fet_row(arrangement="interleave", orientation="alt_DS", contact_end="right")}
```
### Tool report for program 2
```
Proposal 2: built and verified. Overall status: auto_passed.
  stages: drc=passed, lvs=passed, constraints=passed, pex=passed, physical=passed, post-layout simulation/spec=passed
  full-DUT bounding box: 14.855 x 7.125 um = 105.8419 um^2
    row n: width 12.08 um (+ taps 1.70), height 3.595 um; cells grp0 12.08x2.815
    routing channels: heights [1.88, 3.1] um; channel strategy shared
  group 0: active islands 8, cross-device shared diffusion nodes 0, cross-device shared gate conductors 0
```

## Example: C07 (sky130, development size)
Case C07_sky130_sW1_sL1
Circuit: differential pair with current-source loads (textbook topology C07).
Process: SkyWater SKY130 (1.8 V devices).
Target netlist (fixed; sizes in um):
```spice
.subckt C07_sky130_sW1_sL1 VDD VSS VIN1 VIN2 VOUT1 VOUT2 VB1 IB1
XM1 VOUT1 VIN1 IB1 VSS sky130_fd_pr__nfet_01v8 w=4 l=0.3 nf=8
XM2 VOUT2 VIN2 IB1 VSS sky130_fd_pr__nfet_01v8 w=4 l=0.3 nf=8
XM3 VOUT1 VB1 VDD VDD sky130_fd_pr__pfet_01v8 w=4 l=0.3 nf=8
XM4 VOUT2 VB1 VDD VDD sky130_fd_pr__pfet_01v8 w=4 l=0.3 nf=8
.ends C07_sky130_sW1_sL1
```
Fixed sharing groups and rows (2 groups; you must give a plan for every group index):
group 0 (bottom (NMOS) row, body VSS, unit finger width 0.5 um, L 0.3 um):
    M1: nfet D=VOUT1 G=VIN1 S=IB1 B=VSS, nf=8, total W=4 um
    M2: nfet D=VOUT2 G=VIN2 S=IB1 B=VSS, nf=8, total W=4 um
group 1 (middle (PMOS) row, body VDD, unit finger width 0.5 um, L 0.3 um):
    M3: pfet D=VOUT1 G=VB1 S=VDD B=VDD, nf=8, total W=4 um
    M4: pfet D=VOUT2 G=VB1 S=VDD B=VDD, nf=8, total W=4 um
Goal: propose plans so that the generated layout passes every check with the smallest full bounding-box area.


### Program 1
```python
plans = {0: fet_row(arrangement="block", orientation="alt_SD", contact_end="left"), 1: fet_row(arrangement="block", orientation="alt_SD", contact_end="left")}
```
### Tool report for program 1
```
Proposal 1: built and verified. Overall status: auto_passed.
  stages: drc=passed, lvs=passed, constraints=passed, pex=passed, physical=passed, post-layout simulation/spec=passed
  full-DUT bounding box: 12.47 x 13.15 um = 163.9805 um^2
    row n: width 10.55 um (+ taps 1.70), height 3.565 um; cells grp0 10.55x2.785
    row p: width 10.65 um (+ taps 1.70), height 3.565 um; cells grp1 10.65x2.785
    routing channels: heights [1.88, 3.71, 1.88] um; channel strategy shared
  group 0: active islands 2, cross-device shared diffusion nodes 0, cross-device shared gate conductors 0
  group 1: active islands 2, cross-device shared diffusion nodes 0, cross-device shared gate conductors 0
```

### Program 2
```python
plans = {0: fet_row(arrangement="interleave", orientation="alt_DS", contact_end="right"), 1: fet_row(arrangement="interleave", orientation="alt_DS", contact_end="right")}
```
### Tool report for program 2
```
Proposal 2: built and verified. Overall status: auto_passed.
  stages: drc=passed, lvs=passed, constraints=passed, pex=passed, physical=passed, post-layout simulation/spec=passed
  full-DUT bounding box: 21.98 x 15.04 um = 330.5792 um^2
    row n: width 18.88 um (+ taps 1.70), height 3.595 um; cells grp0 18.88x2.815
    row p: width 18.93 um (+ taps 1.70), height 3.595 um; cells grp1 18.93x2.815
    routing channels: heights [1.88, 5.54, 1.88] um; channel strategy shared
  group 0: active islands 16, cross-device shared diffusion nodes 0, cross-device shared gate conductors 0
  group 1: active islands 16, cross-device shared diffusion nodes 0, cross-device shared gate conductors 0
```

### Program 3
```python
plans = {0: fet_row(arrangement="block", orientation="alt_SD", contact_end="left", diffusion="all_legal"), 1: fet_row(arrangement="block", orientation="alt_SD", contact_end="left", diffusion="all_legal")}
```
### Tool report for program 3
```
Proposal 3: REJECTED before building (no geometry was generated).
  - [fet_row_args] fet_row needs exactly ['arrangement', 'contact_end', 'orientation']; got ['arrangement', 'contact_end', 'diffusion', 'orientation'] (line 1) group 0
  - [fet_row_args] fet_row needs exactly ['arrangement', 'contact_end', 'orientation']; got ['arrangement', 'contact_end', 'diffusion', 'orientation'] (line 1) group 1
```
