Each example shows a development circuit (NOT your task circuit), programs that were submitted for it, and the tool report each program received.  Areas of development circuits say nothing about your task's areas.

## Example: C01 (sky130, development size)
Case C01_sky130_sW1_sL1
Circuit: basic current mirror (textbook topology C01).
Process: SkyWater SKY130 (1.8 V devices).
Target netlist (fixed; sizes in um):
```spice
.subckt C01_sky130_sW1_sL1 VSS IB1 IOUT1
XM1 IB1 IB1 VSS VSS sky130_fd_pr__nfet_01v8 w=2 l=0.6 nf=4
XM2 IOUT1 IB1 VSS VSS sky130_fd_pr__nfet_01v8 w=2 l=0.6 nf=4
.ends C01_sky130_sW1_sL1
```
Fixed sharing groups and rows (1 groups; you must give a plan for every group index):
group 0 (bottom (NMOS) row, body VSS, unit finger width 0.5 um, L 0.6 um):
    M1: nfet D=IB1 G=IB1 S=VSS B=VSS, nf=4, total W=2 um
    M2: nfet D=IOUT1 G=IB1 S=VSS B=VSS, nf=4, total W=2 um
Goal: propose plans so that the generated layout passes every check with the smallest full bounding-box area.


### Program 1
```python
plans = {0: axis_plan(arrangement="block", orientation="alt_SD", diffusion="none", gate="per_device", strap_start="bottom", contact_end="left")}
```
### Tool report for program 1
```
Proposal 1: built and verified. Overall status: auto_passed.
  stages: drc=passed, lvs=passed, constraints=passed, pex=passed, physical=passed, post-layout simulation/spec=passed
  full-DUT bounding box: 11.005 x 7.095 um = 78.0805 um^2
    row n: width 8.23 um (+ taps 1.70), height 3.565 um; cells grp0 8.23x2.785
    routing channels: heights [1.88, 3.1] um; channel strategy shared
  group 0: active islands 2, cross-device shared diffusion nodes 0, cross-device shared gate conductors 0
```

### Program 2
```python
plans = {0: SharingPlan(finger_order=[("M1", 0), ("M1", 1), ("M1", 2), ("M1", 3), ("M2", 0), ("M2", 1), ("M2", 2), ("M2", 3)],
            orientations=["SD", "DS", "SD", "DS", "SD", "DS", "SD", "DS"],
            diffusion_joins=[True, True, True, True, True, True, True],
            gate_groups=[GateGroup(fingers=(0, 1, 2, 3, 4, 5, 6, 7), side="bottom", pad_end="left")])}
```
### Tool report for program 2
```
Proposal 2: built and verified. Overall status: auto_passed.
  stages: drc=passed, lvs=passed, constraints=passed, pex=passed, physical=passed, post-layout simulation/spec=passed
  full-DUT bounding box: 10.445 x 6.555 um = 68.467 um^2
    row n: width 7.67 um (+ taps 1.70), height 3.025 um; cells grp0 7.67x2.245
    routing channels: heights [1.88, 3.1] um; channel strategy shared
  group 0: active islands 1, cross-device shared diffusion nodes 1, cross-device shared gate conductors 1
```

## Example: C07 (sky130, development size)
Case C07_sky130_sW1_sL1
Circuit: differential pair with current-source loads (textbook topology C07).
Process: SkyWater SKY130 (1.8 V devices).
Target netlist (fixed; sizes in um):
```spice
.subckt C07_sky130_sW1_sL1 VDD VSS VIN1 VIN2 VOUT1 VOUT2 VB1 IB1
XM1 VOUT1 VIN1 IB1 VSS sky130_fd_pr__nfet_01v8 w=4 l=0.3 nf=8
XM2 VOUT2 VIN2 IB1 VSS sky130_fd_pr__nfet_01v8 w=4 l=0.3 nf=8
XM3 VOUT1 VB1 VDD VDD sky130_fd_pr__pfet_01v8 w=4 l=0.3 nf=8
XM4 VOUT2 VB1 VDD VDD sky130_fd_pr__pfet_01v8 w=4 l=0.3 nf=8
.ends C07_sky130_sW1_sL1
```
Fixed sharing groups and rows (2 groups; you must give a plan for every group index):
group 0 (bottom (NMOS) row, body VSS, unit finger width 0.5 um, L 0.3 um):
    M1: nfet D=VOUT1 G=VIN1 S=IB1 B=VSS, nf=8, total W=4 um
    M2: nfet D=VOUT2 G=VIN2 S=IB1 B=VSS, nf=8, total W=4 um
group 1 (middle (PMOS) row, body VDD, unit finger width 0.5 um, L 0.3 um):
    M3: pfet D=VOUT1 G=VB1 S=VDD B=VDD, nf=8, total W=4 um
    M4: pfet D=VOUT2 G=VB1 S=VDD B=VDD, nf=8, total W=4 um
Goal: propose plans so that the generated layout passes every check with the smallest full bounding-box area.


### Program 1
```python
plans = {0: axis_plan(arrangement="block", orientation="alt_SD", diffusion="none", gate="per_device", strap_start="bottom", contact_end="left"), 1: axis_plan(arrangement="block", orientation="alt_SD", diffusion="none", gate="per_device", strap_start="bottom", contact_end="left")}
```
### Tool report for program 1
```
Proposal 1: built and verified. Overall status: auto_passed.
  stages: drc=passed, lvs=passed, constraints=passed, pex=passed, physical=passed, post-layout simulation/spec=passed
  full-DUT bounding box: 12.47 x 13.15 um = 163.9805 um^2
    row n: width 10.55 um (+ taps 1.70), height 3.565 um; cells grp0 10.55x2.785
    row p: width 10.65 um (+ taps 1.70), height 3.565 um; cells grp1 10.65x2.785
    routing channels: heights [1.88, 3.71, 1.88] um; channel strategy shared
  group 0: active islands 2, cross-device shared diffusion nodes 0, cross-device shared gate conductors 0
  group 1: active islands 2, cross-device shared diffusion nodes 0, cross-device shared gate conductors 0
```

### Program 2
```python
plans = {0: SharingPlan(finger_order=[("M1", 0), ("M1", 1), ("M1", 2), ("M1", 3), ("M1", 4), ("M1", 5), ("M1", 6), ("M1", 7), ("M2", 0), ("M2", 1), ("M2", 2), ("M2", 3), ("M2", 4), ("M2", 5), ("M2", 6), ("M2", 7)],
            orientations=["SD", "DS", "SD", "DS", "SD", "DS", "SD", "DS", "SD", "DS", "SD", "DS", "SD", "DS", "SD", "DS"],
            diffusion_joins=[True, True, True, True, True, True, True, True, True, True, True, True, True, True, True],
            gate_groups=[GateGroup(fingers=(0, 1, 2, 3, 4, 5, 6, 7), side="bottom", pad_end="left"), GateGroup(fingers=(8, 9, 10, 11, 12, 13, 14, 15), side="bottom", pad_end="left")]),
         1: SharingPlan(finger_order=[("M3", 0), ("M3", 1), ("M3", 2), ("M3", 3), ("M3", 4), ("M3", 5), ("M3", 6), ("M3", 7), ("M4", 0), ("M4", 1), ("M4", 2), ("M4", 3), ("M4", 4), ("M4", 5), ("M4", 6), ("M4", 7)],
            orientations=["SD", "DS", "SD", "DS", "SD", "DS", "SD", "DS", "SD", "DS", "SD", "DS", "SD", "DS", "SD", "DS"],
            diffusion_joins=[True, True, True, True, True, True, True, True, True, True, True, True, True, True, True],
            gate_groups=[GateGroup(fingers=(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15), side="bottom", pad_end="left")])}
```
### Tool report for program 2
```
Proposal 2: built and verified. Overall status: auto_passed.
  stages: drc=passed, lvs=passed, constraints=passed, pex=passed, physical=passed, post-layout simulation/spec=passed
  full-DUT bounding box: 11.91 x 13.22 um = 157.4502 um^2
    row n: width 9.99 um (+ taps 1.70), height 3.565 um; cells grp0 9.99x2.785
    row p: width 10.09 um (+ taps 1.70), height 3.025 um; cells grp1 10.09x2.245
    routing channels: heights [1.88, 4.32, 1.88] um; channel strategy shared
  group 0: active islands 1, cross-device shared diffusion nodes 1, cross-device shared gate conductors 0
  group 1: active islands 1, cross-device shared diffusion nodes 1, cross-device shared gate conductors 1
```

### Program 3
```python
plans = {0: SharingPlan(finger_order=[("M1", 0), ("M1", 1)], orientations=["SD", "SD"], diffusion_joins=[True], gate_groups=[GateGroup(fingers=(0, 1), side="bottom", pad_end="left")]), 1: axis_plan(arrangement="block", orientation="alt_SD", diffusion="none", gate="per_device", strap_start="bottom", contact_end="left")}
```
### Tool report for program 3
```
Proposal 3: REJECTED before building (no geometry was generated).
  - [finger_coverage] finger_order must list every unit finger of every device exactly once group 0
```
