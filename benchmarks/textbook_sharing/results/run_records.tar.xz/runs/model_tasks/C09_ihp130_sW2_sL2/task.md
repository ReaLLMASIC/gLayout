# Task C09_ihp130_sW2_sL2
Circuit: telescopic OTA (single-ended) (textbook topology C09).
Process: IHP SG13G2 (1.2 V low-voltage devices).
Target netlist (fixed; sizes in um):
```spice
.subckt C09_ihp130_sW2_sL2 VDD VSS VIN1 VIN2 VOUT1 VB1 IB1
XM1 net018 VIN1 IB1 VSS sg13_lv_nmos w=16u l=0.52u ng=32 m=1
XM2 net016 VIN2 IB1 VSS sg13_lv_nmos w=16u l=0.52u ng=32 m=1
XM3 net04 VB1 net018 VSS sg13_lv_nmos w=16u l=0.52u ng=32 m=1
XM4 VOUT1 VB1 net016 VSS sg13_lv_nmos w=16u l=0.52u ng=32 m=1
XM5 net04 net04 net019 VDD sg13_lv_pmos w=32u l=0.52u ng=64 m=1
XM6 VOUT1 net04 net017 VDD sg13_lv_pmos w=32u l=0.52u ng=64 m=1
XM7 net019 net019 VDD VDD sg13_lv_pmos w=32u l=0.52u ng=64 m=1
XM8 net017 net019 VDD VDD sg13_lv_pmos w=32u l=0.52u ng=64 m=1
.ends C09_ihp130_sW2_sL2
```
Fixed sharing groups and rows (2 groups; you must give a plan for every group index):
group 0 (bottom (NMOS) row, body VSS, unit finger width 0.5 um, L 0.52 um):
    M1: nfet D=net018 G=VIN1 S=IB1 B=VSS, nf=32, total W=16 um
    M2: nfet D=net016 G=VIN2 S=IB1 B=VSS, nf=32, total W=16 um
    M3: nfet D=net04 G=VB1 S=net018 B=VSS, nf=32, total W=16 um
    M4: nfet D=VOUT1 G=VB1 S=net016 B=VSS, nf=32, total W=16 um
group 1 (middle (PMOS) row, body VDD, unit finger width 0.5 um, L 0.52 um):
    M5: pfet D=net04 G=net04 S=net019 B=VDD, nf=64, total W=32 um
    M6: pfet D=VOUT1 G=net04 S=net017 B=VDD, nf=64, total W=32 um
    M7: pfet D=net019 G=net019 S=VDD B=VDD, nf=64, total W=32 um
    M8: pfet D=net017 G=net019 S=VDD B=VDD, nf=64, total W=32 um
Goal: propose plans so that the generated layout passes every check with the smallest full bounding-box area.
