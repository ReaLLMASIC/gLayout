# Task C16_ihp130_sW2_sL2
Circuit: differential pair with resistor loads (textbook topology C16).
Process: IHP SG13G2 (1.2 V low-voltage devices).
Target netlist (fixed; sizes in um):
```spice
.subckt C16_ihp130_sW2_sL2 VDD VSS VIN1 VIN2 VOUT1 VOUT2 IB1
XM1 VOUT1 VIN1 IB1 VSS sg13_lv_nmos w=8u l=0.52u ng=16 m=1
XM2 VOUT2 VIN2 IB1 VSS sg13_lv_nmos w=8u l=0.52u ng=16 m=1
XRR1 VDD VOUT1 rppd w=1u l=46.385u m=1
XRR2 VDD VOUT2 rppd w=1u l=46.385u m=1
.ends C16_ihp130_sW2_sL2
```
Fixed sharing groups and rows (1 groups; you must give a plan for every group index):
group 0 (bottom (NMOS) row, body VSS, unit finger width 0.5 um, L 0.52 um):
    M1: nfet D=VOUT1 G=VIN1 S=IB1 B=VSS, nf=16, total W=8 um
    M2: nfet D=VOUT2 G=VIN2 S=IB1 B=VSS, nf=16, total W=8 um
passive row (fixed, not part of any plan): R1 (res VDD-VOUT1), R2 (res VDD-VOUT2)
Goal: propose plans so that the generated layout passes every check with the smallest full bounding-box area.
