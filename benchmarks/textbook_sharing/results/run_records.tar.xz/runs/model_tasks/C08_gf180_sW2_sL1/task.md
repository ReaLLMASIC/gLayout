# Task C08_gf180_sW2_sL1
Circuit: five-transistor OTA (textbook topology C08).
Process: GlobalFoundries GF180MCU (3.3 V devices).
Target netlist (fixed; sizes in um):
```spice
.subckt C08_gf180_sW2_sL1 VDD VSS VIN1 VIN2 VOUT1 VB1
MM1 net22 VIN1 net23 VSS nfet_03v3 w=8u l=0.56u nf=16 m=1
MM2 VOUT1 VIN2 net23 VSS nfet_03v3 w=8u l=0.56u nf=16 m=1
MM3 net23 VB1 VSS VSS nfet_03v3 w=8u l=0.56u nf=16 m=1
MM4 net22 net22 VDD VDD pfet_03v3 w=4u l=0.56u nf=8 m=1
MM5 VOUT1 net22 VDD VDD pfet_03v3 w=4u l=0.56u nf=8 m=1
.ends C08_gf180_sW2_sL1
```
Fixed sharing groups and rows (2 groups; you must give a plan for every group index):
group 0 (bottom (NMOS) row, body VSS, unit finger width 0.5 um, L 0.56 um):
    M1: nfet D=net22 G=VIN1 S=net23 B=VSS, nf=16, total W=8 um
    M2: nfet D=VOUT1 G=VIN2 S=net23 B=VSS, nf=16, total W=8 um
    M3: nfet D=net23 G=VB1 S=VSS B=VSS, nf=16, total W=8 um
group 1 (middle (PMOS) row, body VDD, unit finger width 0.5 um, L 0.56 um):
    M4: pfet D=net22 G=net22 S=VDD B=VDD, nf=8, total W=4 um
    M5: pfet D=VOUT1 G=net22 S=VDD B=VDD, nf=8, total W=4 um
Goal: propose plans so that the generated layout passes every check with the smallest full bounding-box area.
