# Task C11_ihp130_sW2_sL1
Circuit: two-stage Miller op amp with RC compensation (textbook topology C11).
Process: IHP SG13G2 (1.2 V low-voltage devices).
Target netlist (fixed; sizes in um):
```spice
.subckt C11_ihp130_sW2_sL1 VDD VSS VIN1 VIN2 VOUT1 IB1
XM1 IB1 IB1 VDD VDD sg13_lv_pmos w=4u l=0.26u ng=8 m=1
XM2 net97 IB1 VDD VDD sg13_lv_pmos w=8u l=0.26u ng=16 m=1
XM3 net014 VIN1 net97 VDD sg13_lv_pmos w=8u l=0.26u ng=16 m=1
XM4 net016 VIN2 net97 VDD sg13_lv_pmos w=8u l=0.26u ng=16 m=1
XM5 net014 net014 VSS VSS sg13_lv_nmos w=4u l=0.26u ng=8 m=1
XM6 net016 net014 VSS VSS sg13_lv_nmos w=4u l=0.26u ng=8 m=1
XM7 VOUT1 IB1 VDD VDD sg13_lv_pmos w=8u l=0.26u ng=16 m=1
XM8 VOUT1 net016 VSS VSS sg13_lv_nmos w=8u l=0.26u ng=16 m=1
XRR1 net016 net022 rppd w=1u l=11.38u m=1
XCC1 net022 VOUT1 cap_cmim w=25.82u l=25.82u
.ends C11_ihp130_sW2_sL1
```
Fixed sharing groups and rows (2 groups; you must give a plan for every group index):
group 0 (middle (PMOS) row, body VDD, unit finger width 0.5 um, L 0.26 um):
    M1: pfet D=IB1 G=IB1 S=VDD B=VDD, nf=8, total W=4 um
    M2: pfet D=net97 G=IB1 S=VDD B=VDD, nf=16, total W=8 um
    M3: pfet D=net014 G=VIN1 S=net97 B=VDD, nf=16, total W=8 um
    M4: pfet D=net016 G=VIN2 S=net97 B=VDD, nf=16, total W=8 um
    M7: pfet D=VOUT1 G=IB1 S=VDD B=VDD, nf=16, total W=8 um
group 1 (bottom (NMOS) row, body VSS, unit finger width 0.5 um, L 0.26 um):
    M5: nfet D=net014 G=net014 S=VSS B=VSS, nf=8, total W=4 um
    M6: nfet D=net016 G=net014 S=VSS B=VSS, nf=8, total W=4 um
    M8: nfet D=VOUT1 G=net016 S=VSS B=VSS, nf=16, total W=8 um
passive row (fixed, not part of any plan): R1 (res net016-net022), C1 (cap net022-VOUT1)
Goal: propose plans so that the generated layout passes every check with the smallest full bounding-box area.
