# Task C16_sky130_sW2_sL1
Circuit: differential pair with resistor loads (textbook topology C16).
Process: SkyWater SKY130 (1.8 V devices).
Target netlist (fixed; sizes in um):
```spice
.subckt C16_sky130_sW2_sL1 VDD VSS VIN1 VIN2 VOUT1 VOUT2 IB1
XM1 VOUT1 VIN1 IB1 VSS sky130_fd_pr__nfet_01v8 w=8 l=0.3 nf=16
XM2 VOUT2 VIN2 IB1 VSS sky130_fd_pr__nfet_01v8 w=8 l=0.3 nf=16
XRR1 VDD VOUT1 VSS sky130_fd_pr__res_high_po_0p35 l=17.55 mult=1
XRR2 VDD VOUT2 VSS sky130_fd_pr__res_high_po_0p35 l=17.55 mult=1
.ends C16_sky130_sW2_sL1
```
Fixed sharing groups and rows (1 groups; you must give a plan for every group index):
group 0 (bottom (NMOS) row, body VSS, unit finger width 0.5 um, L 0.3 um):
    M1: nfet D=VOUT1 G=VIN1 S=IB1 B=VSS, nf=16, total W=8 um
    M2: nfet D=VOUT2 G=VIN2 S=IB1 B=VSS, nf=16, total W=8 um
passive row (fixed, not part of any plan): R1 (res VDD-VOUT1), R2 (res VDD-VOUT2)
Goal: propose plans so that the generated layout passes every check with the smallest full bounding-box area.
