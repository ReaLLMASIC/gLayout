# Task C08_ihp130_sW2_sL2
Circuit: five-transistor OTA (textbook topology C08).
Process: IHP SG13G2 (1.2 V low-voltage devices).
Target netlist (fixed; sizes in um):
```spice
.subckt C08_ihp130_sW2_sL2 VDD VSS VIN1 VIN2 VOUT1 VB1
XM1 net22 VIN1 net23 VSS sg13_lv_nmos w=8u l=0.78u ng=16 m=1
XM2 VOUT1 VIN2 net23 VSS sg13_lv_nmos w=8u l=0.78u ng=16 m=1
XM3 net23 VB1 VSS VSS sg13_lv_nmos w=8u l=0.78u ng=16 m=1
XM4 net22 net22 VDD VDD sg13_lv_pmos w=4u l=0.78u ng=8 m=1
XM5 VOUT1 net22 VDD VDD sg13_lv_pmos w=4u l=0.78u ng=8 m=1
.ends C08_ihp130_sW2_sL2
```
Fixed sharing groups and rows (2 groups; you must give a plan for every group index):
group 0 (bottom (NMOS) row, body VSS, unit finger width 0.5 um, L 0.78 um):
    M1: nfet D=net22 G=VIN1 S=net23 B=VSS, nf=16, total W=8 um
    M2: nfet D=VOUT1 G=VIN2 S=net23 B=VSS, nf=16, total W=8 um
    M3: nfet D=net23 G=VB1 S=VSS B=VSS, nf=16, total W=8 um
group 1 (middle (PMOS) row, body VDD, unit finger width 0.5 um, L 0.78 um):
    M4: pfet D=net22 G=net22 S=VDD B=VDD, nf=8, total W=4 um
    M5: pfet D=VOUT1 G=net22 S=VDD B=VDD, nf=8, total W=4 um
Goal: propose plans so that the generated layout passes every check with the smallest full bounding-box area.
