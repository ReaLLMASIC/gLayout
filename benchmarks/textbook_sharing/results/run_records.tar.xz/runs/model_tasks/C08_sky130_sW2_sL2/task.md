# Task C08_sky130_sW2_sL2
Circuit: five-transistor OTA (textbook topology C08).
Process: SkyWater SKY130 (1.8 V devices).
Target netlist (fixed; sizes in um):
```spice
.subckt C08_sky130_sW2_sL2 VDD VSS VIN1 VIN2 VOUT1 VB1
XM1 net22 VIN1 net23 VSS sky130_fd_pr__nfet_01v8 w=8 l=0.6 nf=16
XM2 VOUT1 VIN2 net23 VSS sky130_fd_pr__nfet_01v8 w=8 l=0.6 nf=16
XM3 net23 VB1 VSS VSS sky130_fd_pr__nfet_01v8 w=8 l=0.6 nf=16
XM4 net22 net22 VDD VDD sky130_fd_pr__pfet_01v8 w=4 l=0.6 nf=8
XM5 VOUT1 net22 VDD VDD sky130_fd_pr__pfet_01v8 w=4 l=0.6 nf=8
.ends C08_sky130_sW2_sL2
```
Fixed sharing groups and rows (2 groups; you must give a plan for every group index):
group 0 (bottom (NMOS) row, body VSS, unit finger width 0.5 um, L 0.6 um):
    M1: nfet D=net22 G=VIN1 S=net23 B=VSS, nf=16, total W=8 um
    M2: nfet D=VOUT1 G=VIN2 S=net23 B=VSS, nf=16, total W=8 um
    M3: nfet D=net23 G=VB1 S=VSS B=VSS, nf=16, total W=8 um
group 1 (middle (PMOS) row, body VDD, unit finger width 0.5 um, L 0.6 um):
    M4: pfet D=net22 G=net22 S=VDD B=VDD, nf=8, total W=4 um
    M5: pfet D=VOUT1 G=net22 S=VDD B=VDD, nf=8, total W=4 um
Goal: propose plans so that the generated layout passes every check with the smallest full bounding-box area.
