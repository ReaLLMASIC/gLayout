# Task C02_ihp130_sW2_sL2
Circuit: cascode current mirror (textbook topology C02).
Process: IHP SG13G2 (1.2 V low-voltage devices).
Target netlist (fixed; sizes in um):
```spice
.subckt C02_ihp130_sW2_sL2 VSS IIN1 IOUT1
XM1 IIN1 IIN1 net6 VSS sg13_lv_nmos w=4u l=1.04u ng=8 m=1
XM2 net6 net6 VSS VSS sg13_lv_nmos w=4u l=1.04u ng=8 m=1
XM3 IOUT1 IIN1 net12 VSS sg13_lv_nmos w=4u l=1.04u ng=8 m=1
XM4 net12 net6 VSS VSS sg13_lv_nmos w=4u l=1.04u ng=8 m=1
.ends C02_ihp130_sW2_sL2
```
Fixed sharing groups and rows (1 groups; you must give a plan for every group index):
group 0 (bottom (NMOS) row, body VSS, unit finger width 0.5 um, L 1.04 um):
    M1: nfet D=IIN1 G=IIN1 S=net6 B=VSS, nf=8, total W=4 um
    M2: nfet D=net6 G=net6 S=VSS B=VSS, nf=8, total W=4 um
    M3: nfet D=IOUT1 G=IIN1 S=net12 B=VSS, nf=8, total W=4 um
    M4: nfet D=net12 G=net6 S=VSS B=VSS, nf=8, total W=4 um
Goal: propose plans so that the generated layout passes every check with the smallest full bounding-box area.
