# Task C11_gf180_sW2_sL2
Circuit: two-stage Miller op amp with RC compensation (textbook topology C11).
Process: GlobalFoundries GF180MCU (3.3 V devices).
Target netlist (fixed; sizes in um):
```spice
.subckt C11_gf180_sW2_sL2 VDD VSS VIN1 VIN2 VOUT1 IB1
MM1 IB1 IB1 VDD VDD pfet_03v3 w=4u l=1.12u nf=8 m=1
MM2 net97 IB1 VDD VDD pfet_03v3 w=8u l=1.12u nf=16 m=1
MM3 net014 VIN1 net97 VDD pfet_03v3 w=8u l=1.12u nf=16 m=1
MM4 net016 VIN2 net97 VDD pfet_03v3 w=8u l=1.12u nf=16 m=1
MM5 net014 net014 VSS VSS nfet_03v3 w=4u l=1.12u nf=8 m=1
MM6 net016 net014 VSS VSS nfet_03v3 w=4u l=1.12u nf=8 m=1
MM7 VOUT1 IB1 VDD VDD pfet_03v3 w=8u l=1.12u nf=16 m=1
MM8 VOUT1 net016 VSS VSS nfet_03v3 w=8u l=1.12u nf=16 m=1
XRR1 net016 net022 VSS ppolyf_u r_width=1u r_length=7.795u
XCC1 net022 VOUT1 cap_mim_2f0fF c_width=22.365u c_length=22.365u
.ends C11_gf180_sW2_sL2
```
Fixed sharing groups and rows (2 groups; you must give a plan for every group index):
group 0 (middle (PMOS) row, body VDD, unit finger width 0.5 um, L 1.12 um):
    M1: pfet D=IB1 G=IB1 S=VDD B=VDD, nf=8, total W=4 um
    M2: pfet D=net97 G=IB1 S=VDD B=VDD, nf=16, total W=8 um
    M3: pfet D=net014 G=VIN1 S=net97 B=VDD, nf=16, total W=8 um
    M4: pfet D=net016 G=VIN2 S=net97 B=VDD, nf=16, total W=8 um
    M7: pfet D=VOUT1 G=IB1 S=VDD B=VDD, nf=16, total W=8 um
group 1 (bottom (NMOS) row, body VSS, unit finger width 0.5 um, L 1.12 um):
    M5: nfet D=net014 G=net014 S=VSS B=VSS, nf=8, total W=4 um
    M6: nfet D=net016 G=net014 S=VSS B=VSS, nf=8, total W=4 um
    M8: nfet D=VOUT1 G=net016 S=VSS B=VSS, nf=16, total W=8 um
passive row (fixed, not part of any plan): R1 (res net016-net022), C1 (cap net022-VOUT1)
Goal: propose plans so that the generated layout passes every check with the smallest full bounding-box area.
